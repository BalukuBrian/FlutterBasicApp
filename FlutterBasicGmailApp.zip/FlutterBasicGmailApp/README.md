# flutter_basic_app

This Project tends to create a simple flutter app
