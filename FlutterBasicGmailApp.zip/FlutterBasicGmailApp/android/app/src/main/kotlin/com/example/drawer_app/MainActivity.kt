package com.example.drawer_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
